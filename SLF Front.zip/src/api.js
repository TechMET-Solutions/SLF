export const API = "http://localhost:5000";
//  export const API = "https://slfuatbackend.1on1screen.com";