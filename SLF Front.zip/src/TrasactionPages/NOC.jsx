import axios from "axios";
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { API } from "../api";

function NOC() {
    const location = useLocation();
    const { loanId } = location.state || {};
    const [loading, setLoading] = useState(false);
    const [loanData, setLoanData] = useState({});
    console.log(loanData,"loanData")
    const [error, setError] = useState(null);
const navigate = useNavigate();
    useEffect(() => {
        document.title = "SLF | NOC";
        if (loanId) {
            fetchLoanData();
        }
    }, [loanId]);

    const fetchLoanData = async () => {
        try {
            setLoading(true);
            const response = await axios.get(
                `${API}/Transactions/goldloan/getLoan/${loanId}`
            );

            
            // ✅ Set and log loan data
            const data = response.data.loanApplication || {};
            setLoanData(data);
            console.log("✅ Loan Data:", data);

            setError(null);
        } catch (err) {
            console.error("❌ Error fetching loan data:", err);
            setError("Failed to load loan data");
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;
    const safeParse = (value) => {
    try {
        if (!value) return [];

        // Already array
        if (Array.isArray(value)) return value;

        // Already object → not a valid JSON string → return []
        if (typeof value === "object") return [];

        // "[object Object]" case
        if (value === "[object Object]") return [];

        return JSON.parse(value);
    } catch {
        return [];
    }
};

const payments = safeParse(loanData?.payments_Details);

    console.log(payments, "payments")
    
    const totalCash = payments
  .filter(p => p.paidBy?.toLowerCase() === "cash")
  .reduce((sum, p) => sum + Number(p.customerAmount || 0), 0);

const totalBank = payments
  .filter(p => p.paidBy?.toLowerCase() !== "cash")
  .reduce((sum, p) => sum + Number(p.customerAmount || 0), 0);
    return (
        <div className="flex flex-col items-center mt-5">
            {/* Header Section */}
            <div className="flex items-center justify-between px-6 py-4 w-[1290px] h-[62px] border border-gray-200 rounded-[11px] shadow-sm">
                <h2 className="text-black font-bold text-[20px] font-['Source_Sans_3']">
                    S. Lunawat Finance Pvt. Ltd.
                </h2>
<button className="w-[74px] h-[24px] rounded-[3.75px] bg-[#C1121F] text-white text-[10px]" onClick={() => navigate("/")}>
                Exit
              </button>
            </div>

            {/* Table Section */}
            <div className="bg-white w-[1290px] mt-6">
                <table className="w-full border border-gray-400 text-sm border-collapse">
                    <tbody>

                        <tr className="border">
                            <td colSpan="7" className="py-6 text-center">
                                <p className="text-lg">
                                    Amount To Be Given Amount
                                </p >
                                <p className="text-lg font-semibold">
                                    कस्टमर ना-हरकत प्रमाण.पत्र (NoC - To Be Attached With Loan Payment Slip)
                                </p>

                            </td>
                        </tr>
                        {/* Customer Name */}
                        <tr className="border">
                            <td className="border px-2 py-1 font-semibold w-[180px]">
                                ग्राहकाचे नाव -
                            </td>
                            <td colSpan="6" className="border px-2 py-1">
                                {loanData.BorrowerId} - {loanData.Print_Name}
                            </td>
                        </tr>

                        {/* Loan Info */}
                        <tr className="border">
                            <td className="border px-2 py-1 font-semibold">कर्ज क्रमांक -</td>
                            <td colSpan="4" className="border px-2 py-1">{loanData.id}</td>
                            <td className="border px-2 py-1 font-semibold">कर्ज दिनांक -</td>
                            <td colSpan="4" className="border px-2 py-1">
                              
                              <p>{new Date(loanData.approval_date).toLocaleDateString("en-GB")}</p>

                            </td>
                        </tr>

                        {/* Loan Amount Details */}
                        <tr className="border">
                            <td
                                rowSpan="3"
                                className="border px-2 py-1  font-semibold w-[180px]"
                            >
                                कर्ज रक्कम -
                            </td>
                            <td colSpan="2" className="border text-center  px-2 py-1">
                                New Loan Amount: ₹{loanData.Loan_amount}
                            </td>
                            <td colSpan="2" className="border text-center      px-2 py-1 font-semibold">
                                Less: Repay Amount (Old Loan Closed)
                            </td>
                            <td colSpan="2" className="border text-center px-2 py-1">
                                Amount To Be Given Amount
                            </td>
                        </tr>

                        <tr className="border text-center">
                            <td className="border px-2 py-1 font-semibold">CASH</td>
                            <td className="border px-2 py-1">{totalCash}/-</td>
                            <td className="border px-2 py-1 font-semibold">CASH</td>
                            <td className="border px-2 py-1">0 /-</td>
                            <td className="border px-2 py-1 font-semibold">CASH</td>
                            <td className="border px-2 py-1">0 /-</td>
                        </tr>

                        <tr className="border text-center">
                            <td className="border px-2 py-1 font-semibold">TOTAL BANK</td>
                            <td className="border px-2 py-1">{totalBank}</td>
                            <td className="border px-2 py-1 font-semibold">BANK</td>
                            <td className="border px-2 py-1"></td>
                            <td className="border px-2 py-1 font-semibold">BANK</td>
                            <td className="border px-2 py-1"></td>

                        </tr>

                      
                        {payments.map((p, i) => (
  <tr key={i} className="border text-left">
    <td className="border px-2 py-1 font-semibold">
      Bank {String(i + 1).padStart(2, "0")} Details
    </td>
  <td colSpan="6" className="border px-2 py-1">
  {loanData.Print_Name} &nbsp; | &nbsp;
  {p.paidBy === "Cash" ? "Cash" : p.bank} &nbsp; | &nbsp;
  UTR : {p.utrNumber} &nbsp; | &nbsp;
  Amount : ₹{p.customerAmount}
</td>

  </tr>
))}

                        {/* Marathi Declaration */}
                        <tr>
                            <td colSpan="7" className="border px-2 py-3 text-justify leading-snug">
                                मी जे SLF कंपनीकडून लोन घेत आहे, ती सदर रक्कम वरील बँक-खात्यात जमा करण्यास माझी कोणतीही हरकत नाही. जर लोन पावती वरील नाव व बँक खात्याचे नाव वेगळे असल्यास त्यास माझी पूर्ण संमती आहे. मी उपरोक्त ग्राहक असून मी कंपनीकडून घेतलेल्या कर्जाची रक्कम SLF कंपनीने मी लिहून दिलेल्या खात्यावर वर्ग झाल्यानंतर SLF कंपनीची कोणतीही जबाबदारी राहणार नाही. ती  जबाबदारी व कर्ज परत-फेडीची जबाबदारी माझी राहील. त्यासरशी मी खाली सही केली.
                            </td>
                        </tr>

                        {/* Signature Section */}
                        <tr>
                            <td rowSpan="2" className="border px-2 py-1 font-semibold w-[180px]">
                                ग्राहकाची सही -
                            </td>
                            <td colSpan="3" className="border px-2 py-1 text-left">
                                Loan Created By: <br /> - Nitin.Suryawanshi@Slunawat.Com
                            </td>
                            <td colSpan="3" className="border px-2 py-1 text-left">
                                Loan Approved By: <br /> - Nitin.Suryawanshi@Slunawat.Com
                            </td>

                        </tr>
                        <tr>
                            <td colSpan="3" className="border px-2 py-1 text-left">
                                Bank Added By: <br /> -
                            </td>
                            <td colSpan="3" className="border px-2 py-1 text-left">
                                Bank Approved By: <br /> -
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default NOC;
