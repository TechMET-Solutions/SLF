import React from 'react'

function AuctionApplication() {
  return (
    <div className = '' >AuctionApplication</div>
  )
}

export default AuctionApplication