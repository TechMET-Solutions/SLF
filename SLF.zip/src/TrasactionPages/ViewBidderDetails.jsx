import { useEffect, useState } from "react";
import { IoMdImage } from "react-icons/io";
import { useLocation } from "react-router-dom";
import { viewBidderApi } from "../API/Transaction/Auction/BidderApi"; // adjust import path
import profileempty from "../assets/profileempty.png";

const ViewBidderDetails = () => {
  const location = useLocation();
  const { item } = location.state || {};
  const id = item;
  console.log("id ",id);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [formData, setFormData] = useState({
    bidder_name: "",
    mobile_no: "",
    alt_mob_no: "",
    email: "",
    personal_address: "",
    shop_address: "",
    landline_no: "",
    landline_no2: "",
    firm_name: "",
    gst_no: "",
    aadhar_no: "",
    aadharFile: "",
    pan_no: "",
    panFile: "",
    bank_name: "",
    account_no: "",
    ifsc_code: "",
    account_holder_name: "",
    bank_address: "",
    profile_photo: "",
  });

  useEffect(() => {
    const fetchBidderData = async () => {
      setLoading(true);
      try {
        const res = await viewBidderApi(id);
        if (res?.bidder) {
          setFormData(res.bidder);
        } else {
          setError("No bidder data found.");
        }
      } catch (err) {
        console.error(err);
        setError("Failed to fetch bidder details.");
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchBidderData();
  }, [id]);

  if (loading) return <p className="text-center mt-10">Loading bidder details...</p>;
  if (error) return <p className="text-center text-red-500">{error}</p>;

  return (
    <div className="flex flex-col items-center mt-5">
      {/* Header Section */}
      <div className="flex items-center justify-between px-6 py-4 w-[1290px] h-[62px] border border-gray-200 rounded-[11px] shadow-sm sticky top-[80px] z-40">
        <h2 className="text-red-600 font-bold text-[20px] leading-[1.48] font-['Source_Sans_3']">
          View Bidder Details
        </h2>
        <div className="flex items-center gap-5">
          <button
            className="bg-[#C1121F] text-white text-[10px] w-[74px] h-[24px] rounded-[3.75px] hover:bg-red-700 transition"
            onClick={() => window.history.back()}
          >
            Exit
          </button>
        </div>
      </div>

      <div className="w-full px-[110px]">
        {/* Bidder Information Section */}
        <div className="w-full  ">
  <div className="bg-[#FFE6E6] mt-2 p-6">

    <h1 className="text-blue-900 font-semibold text-xl mb-6">
      Bidder Information
    </h1>

    <div className="flex flex-col lg:flex-row ">

      {/* ================= LEFT SECTION ================= */}
      <div className="flex-1">

        {/* Row 1 */}
        <div className="flex flex-wrap gap-4 mb-4">

          <div className="w-[180px]">
            <label className="text-gray-900 font-medium">Bidder Name</label>
            <p className="text-gray-700">{formData.bidder_name}</p>
          </div>

          <div className="w-[130px]">
            <label className="text-gray-900 font-medium">Mobile Number</label>
            <p className="text-gray-700">{formData.mobile_no}</p>
          </div>

          <div className="w-[130px]">
            <label className="text-gray-900 font-medium">Alt Mobile Number</label>
            <p className="text-gray-700">{formData.alt_mob_no || "N/A"}</p>
          </div>

          <div className="w-[150px]">
            <label className="text-gray-900 font-medium">Email</label>
            <p className="text-gray-700">{formData.email || "N/A"}</p>
          </div>

          <div className="w-[200px]">
            <label className="text-gray-900 font-medium">Personal Address</label>
            <p className="text-gray-700">{formData.personal_address || "N/A"}</p>
          </div>

          <div className="w-[200px]">
            <label className="text-gray-900 font-medium">Shop Address</label>
            <p className="text-gray-700">{formData.shop_address || "N/A"}</p>
          </div>

          <div className="w-[130px]">
            <label className="text-gray-900 font-medium">Landline No</label>
            <p className="text-gray-700">{formData.landline_no || "N/A"}</p>
          </div>

          <div className="w-[130px]">
            <label className="text-gray-900 font-medium">Landline No 2</label>
            <p className="text-gray-700">{formData.landline_no2 || "N/A"}</p>
                  </div>
                    <div className="w-[120px]">
            <label className="text-gray-900 font-medium">Firm Name</label>
            <p className="text-gray-700">{formData.firm_name || "N/A"}</p>
                  </div>
                  <div className="w-[150px]">
            <label className="text-gray-900 font-medium">GST No</label>
            <p className="text-gray-700">{formData.gst_no || "N/A"}</p>
          </div>

                  <div className="w-[100px]">
            <label className="text-gray-900 font-medium">Aadhar No</label>
            <p className="text-gray-700">{formData.aadhar_no || "N/A"}</p>
          </div>

                   

                   <div className="w-[100px]">
            <label className="text-gray-900 font-medium">Pan No</label>
            <p className="text-gray-700">{formData.pan_no || "N/A"}</p>
          </div>

        </div>

        {/* Row 2 */}
        <div className="flex flex-wrap gap-4">

        

          

          

        

         

          <div className="w-[200px]">
            <label className="text-gray-900 font-medium">View Pan</label>
            {formData.panFile ? (
              <a
                href={formData.panFile}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-blue-600 hover:underline"
              >
                <IoMdImage className="text-black text-lg" />
                <span>View Pan File</span>
              </a>
            ) : (
              <p className="text-gray-700">N/A</p>
            )}
          </div>

                   <div className="w-[200px]">
            <label className="text-gray-900 font-medium">View Aadhar</label>
            {formData.aadharFile ? (
              <a
                href={formData.aadharFile}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-blue-600 hover:underline"
              >
                <IoMdImage className="text-black text-lg" />
                <span>View Aadhaar File</span>
              </a>
            ) : (
              <p className="text-gray-700">N/A</p>
            )}
          </div>

        </div>

      </div>

      {/* ================= RIGHT SECTION ================= */}
      <div className="w-[150px] rounded-md  flex flex-col items-center">

        <h3 className="font-semibold text-gray-900 mb-4">
          Bidder Profile
        </h3>

        <img
          src={formData.bidder_photo || profileempty}
          alt="profile"
          className="h-[120px] w-[120px] border border-gray-300 object-cover rounded"
        />

      </div>

    </div>

  </div>
</div>


        <div className="bg-[#F7F7FF] p-5 mb-5 ">
          <h1 className="text-blue-900 font-semibold text-xl mb-6">
            Add Bank Details
          </h1>

          <div className="flex flex-wrap gap-8">
            <div className="flex flex-col gap-1 w-[200px]">
              <label className="text-gray-900 font-semibold">Account Number</label>
              <p className="text-gray-700 font-normal">
                {formData.account_no || "N/A"}
              </p>
            </div>

            <div className="flex flex-col gap-1 w-[150px]">
              <label className="text-gray-900 font-semibold">IFSC Code</label>
              <p className="text-gray-700 font-normal">
                {formData.ifsc_code || "N/A"}
              </p>
            </div>

            <div className="flex flex-col gap-1 w-[250px]">
              <label className="text-gray-900 font-semibold">Account Holder Name</label>
              <p className="text-gray-700 font-normal">
                {formData.account_holder_name || "N/A"}
              </p>
            </div>

            <div className="flex flex-col gap-1 w-[200px]">
              <label className="text-gray-900 font-semibold">Bank Name</label>
              <p className="text-gray-700 font-normal">
                {formData.bank_name || "N/A"}
              </p>
            </div>

            <div className="flex flex-col gap-1 w-[200px]">
              <label className="text-gray-900 font-semibold">Bank Address</label>
              <p className="text-gray-700 font-normal">
                {formData.bank_address || "N/A"}
              </p>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

export default ViewBidderDetails;
