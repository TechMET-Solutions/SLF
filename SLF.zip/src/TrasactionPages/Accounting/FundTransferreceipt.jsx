// import axios from "axios";
// import { Plus, Search } from "lucide-react";
// import { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { API } from "../../api";

// const FundTransferReceipt = () => {
//   const navigate = useNavigate();
//   const [list, setList] = useState([]);

//   useEffect(() => {
//     fetchFundTransfers();
//   }, []);

//   const fetchFundTransfers = async () => {
//     try {
//       const res = await axios.get(
//         `${API}/FundTransfer/FundTransfer/Receipt/list`,
//       );
//       setList(res.data.data);
//     } catch (error) {
//       console.error("Error fetching list:", error);
//     }
//   };

//   // Exact system colors from screenshots
//   const navyBlue = "bg-[#0D3082]";
//   const tealHeader = "bg-[#008b8b]";

//   // Compact input style for the search bar
//   const inputClass =
//     "border border-gray-300 rounded-sm px-1 py-0.5 text-[11px] outline-none focus:border-blue-500 w-[140px] h-[22px]";
//   const labelClass = "text-[11px] font-bold text-gray-700";
//   const handleDelete = async (id) => {
//     if (!window.confirm("Are you sure you want to delete this record?")) return;

//     try {
//       await axios.delete(
//         `${API}/FundTransfer/FundTransfer/Receipt/delete/${id}`,
//       );

//       alert("Deleted Successfully ✅");
//       fetchFundTransfers(); // refresh list
//     } catch (error) {
//       console.error("Delete error:", error);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-white font-sans text-gray-800 p-5">
//       <div className="p-1">
//         {/* 2. List Header with +Add Button */}
//         <div
//           className={`${tealHeader} text-white px-3 py-1 text-[12px] font-bold flex justify-between items-center rounded-t-sm`}
//         >
//           <span className="font-medium">Fund Transfer Receipt List</span>
//           <button
//             onClick={() => navigate("/FundTransfer/Receipt/create")}
//             className={`${navyBlue} hover:bg-blue-900 px-2 py-0.5 rounded-sm text-[10px] flex items-center gap-1 border border-white/20`}
//           >
//             <Plus size={12} /> Add
//           </button>
//         </div>

//         {/* 3. Search Bar Area */}
//         <div className="p-2 border-x border-b border-gray-200 flex items-center gap-4 bg-white mb-1">
//           <div className="flex items-center gap-2">
//             <label className={labelClass}>
//               Pay Mode <span className="text-red-500">*</span>
//             </label>
//             <select className={inputClass}>
//               <option>--Select All--</option>
//             </select>
//           </div>
//           <div className="flex items-center gap-2">
//             <label className={labelClass}>
//               Account <span className="text-red-500">*</span>
//             </label>
//             <select className={inputClass}>
//               <option>--Select All--</option>
//             </select>
//           </div>
//           <button
//             className={`${navyBlue} text-white px-4 py-0.5 rounded-sm text-[11px] font-bold flex items-center gap-1`}
//           >
//             <Search size={12} /> Search
//           </button>
//         </div>

//         {/* 4. Data Grid */}
//         <div className="overflow-x-auto border border-gray-300">
//           <table className="w-full text-left border-collapse table-auto">
//             <thead>
//               <tr className="bg-gray-100 text-gray-700 text-[10px] font-bold border-b border-gray-300">
//                 <th className="p-1.5 border-r border-gray-300">Doc No</th>
//                 <th className="p-1.5 border-r border-gray-300">Doc Date</th>
//                 <th className="p-1.5 border-r border-gray-300">Paymode</th>
//                 <th className="p-1.5 border-r border-gray-300">Branch Name</th>
//                 {/* <th className="p-1.5 border-r border-gray-300">
//                   Account Ledger Name
//                 </th> */}
//                 <th className="p-1.5 border-r border-gray-300">Amount</th>
//                 <th className="p-1.5 border-r border-gray-300">MOP</th>
//                 <th className="p-1.5 border-r border-gray-300">Add By</th>
//                 <th className="p-1.5 border-r border-gray-300">Add On</th>
//                 <th className="p-1.5 border-r border-gray-300">
//                   Receipt Status
//                 </th>
//                 <th className="p-1.5 text-center">Action</th>
//               </tr>
//             </thead>
//             <tbody className="text-[11px] divide-y divide-gray-200">
//               {list.map((item, i) =>
//                 item.transfer_details.map((td, index) => (
//                   <tr key={`${i}-${index}`} className="hover:bg-blue-50/50">
//                     <td className="p-1.5 border-r text-blue-800">{item.id}</td>

//                     <td className="p-1.5 border-r">
//                       {new Date(item.doc_date).toLocaleDateString("en-GB")}
//                     </td>

//                     <td className="p-1.5 border-r">{item.pay_mode}</td>

//                     <td className="p-1.5 border-r">{td.toBranch}</td>

//                     {/* <td className="p-1.5 border-r font-medium">
//                       {item.account}
//                     </td> */}

//                     <td className="p-1.5 border-r font-bold">
//                       {td.amount || "-"}
//                     </td>

//                     <td className="p-1.5 border-r">{item.pay_mode}</td>

//                     <td className="p-1.5 border-r text-gray-500">Admin</td>

//                     <td className="p-1.5 border-r">
//                       {item.created_at?.split("T")[0]}
//                     </td>

//                     <td className="p-1.5 border-r text-green-700 font-bold">
//                       Received
//                     </td>

//                     <td className="p-1.5 text-center whitespace-nowrap">
//                       <span
//                         className="text-blue-600 cursor-pointer font-bold mr-2"
//                         onClick={() =>
//                           navigate("/FundTransfer/Receipt/create", {
//                             state: {
//                               fundData: {
//                                 ...item,
//                                 transferDetails: item.transfer_details,
//                               },
//                             },
//                           })
//                         }
//                       >
//                         View
//                       </span>

//                       <span
//                         className="text-red-600 cursor-pointer font-bold"
//                         onClick={() => handleDelete(item.id)}
//                       >
//                         Delete
//                       </span>
//                     </td>
//                   </tr>
//                 )),
//               )}
//             </tbody>
//           </table>
//         </div>

//         {/* Footer */}
//         {/* <div className={`${navyBlue} text-white text-[10px] text-center py-1.5 mt-2 rounded-sm uppercase`}>
//           © Copyright Maraekat Infotech Ltd, 2015. All rights reserved.
//         </div> */}
//       </div>
//     </div>
//   );
// };

// export default FundTransferReceipt;
import axios from "axios";
import { Eye, Plus, Search, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { API } from "../../api";

const FundTransferReceipt = () => {
  const navigate = useNavigate();
  const [list, setList] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  console.log(list, "list");
  const [payMode, setPayMode] = useState("");
  // useEffect(() => {
  //   fetchFundTransfers();
  // }, []);

  const [selectedBranch, setSelectedBranch] = useState("");
  const [selectedBranchid, setSelectedBranchid] = useState("");

  useEffect(() => {
    debugger;
    const userData = JSON.parse(sessionStorage.getItem("userData"));

    if (userData && userData.branchId) {
      console.log("Branch ID:", userData.branchId.branch_code);
      console.log("Branch Name:", userData.branchId.branch_name);
      // setSelectedYear(userData.financialYear)
      setSelectedBranch(userData.branchId.branch_name);
      setSelectedBranchid(userData.branchId.id);

      fetchFundTransfers(userData.branchId.id);
    }
  }, []);

  //

  const fetchFundTransfers = async (selectedBranchid) => {
    debugger;
    try {
      if (!selectedBranchid) return; // wait until branchId is set

      const res = await axios.get(
        `${API}/api/FundTransfer/listReceipt`,
        {
          params: {
            branchId: selectedBranchid,
          },
        },
      );

      setList(res.data.data);
    } catch (error) {
      console.error("Error fetching list:", error);
    }
  };

  // Exact system colors from screenshots
  const navyBlue = "bg-[#0D3082]";
  const tealHeader = "bg-[#008b8b]";

  // Compact input style for the search bar
  const inputClass =
    "border border-gray-300 rounded-sm px-1 py-0.5 text-[11px] outline-none focus:border-blue-500 w-[140px] h-[22px]";
  const labelClass = "text-[11px] font-bold text-gray-700";
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this record?")) return;

    try {
      await axios.delete(`${API}/api/FundTransfer/Delete/${id}`);

      alert("Deleted Successfully ✅");
      fetchFundTransfers(); // refresh list
    } catch (error) {
      console.error("Delete error:", error);
    }
  };
  const handleApprove = async () => {
    try {
      const response = await fetch(
        `${API}/api/FundTransfer/status/${selectedItem.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            status: "Accepted",
          }),
        },
      );

      const data = await response.json();

      if (data.success) {
        alert("Fund Transfer Accepted Successfully");
        setIsModalOpen(false);
        fetchFundTransfers(); // refresh table
      }
    } catch (error) {
      console.error("Approve Error:", error);
    }
  };
  const handleReject = async () => {
    try {
      const response = await fetch(
        `${API}/api/FundTransfer/status/${selectedItem.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            status: "Rejected",
          }),
        },
      );

      const data = await response.json();

      if (data.success) {
        alert("Fund Transfer Rejected Successfully");
        setIsModalOpen(false);
        fetchFundTransfers(); // refresh table
      }
    } catch (error) {
      console.error("Reject Error:", error);
    }
  };
  return (
    <div className="min-h-screen bg-white font-sans text-gray-800 ">

       <div className="flex justify-center p-5 ">
        <div className="flex items-center px-6 py-4 border-b mt-5 w-[1290px] h-[62px] border rounded-[11px] border-gray-200 justify-between ">
          {/* Left heading */}
          <h2
            style={{
              fontFamily: "Source Sans 3, sans-serif",
              fontWeight: 700,
              fontSize: "20px",
              lineHeight: "148%",
              letterSpacing: "0em",
            }}
            className="text-red-600"
          >
           FT Receipt 
          </h2>

          {/* Right section (search + buttons) */}
          <div className="flex items-center gap-6">
            {/* Search section */}
           
           
            {/* Buttons stuck to right */}
            <div className="flex gap-3">
              {/* <button
                style={{
                  width: "74px",
                  height: "24px",
                  borderRadius: "3.75px",
                }}
                // onClick={() => setIsModalOpen(true)}
                className="bg-[#0A2478] text-white text-[11.25px] font-source font-normal flex items-center justify-center"
              >
                Add
              </button> */}

              <button
                onClick={() => navigate("/")}
                className="text-white px-[6.25px] py-[6.25px] rounded-[3.75px] bg-[#C1121F] w-[74px] h-[24px] opacity-100 text-[10px]"
              >
                Exit
              </button>

            </div>
          </div>
        </div>
      </div>
      <div className="w-[1500px]">
      
      

        {/* 4. Data Grid */}
        <div className='ml-[110px] mr-[110px] mt-2'>
<div className="overflow-x-auto  border-gray-300">
          <table className=" text-left border-collapse table-auto">
            <thead className="bg-[#0A2478] text-white text-sm">
              <tr className=" text-white text-[12px] font-bold border-b border-gray-300">
                <th className="p-1.5 border-r  border-gray-300 w-[100px]">Doc No</th>
                <th className="p-1.5 border-r  border-gray-300 w-[100px]">Doc Date</th>
                {/* <th className="p-1.5 bord er-r border-gray-300">Paymode</th> */}
                <th className="p-1.5 border-r  border-gray-300 w-[150px]">From Branch</th>
                <th className="p-1.5 border-r  border-gray-300 w-[100px]">To Branch</th>
                {/* <th className="p-1.5 bord er-r border-gray-300">
                  Account Ledger Name 
                </th> */} 
                <th className="p-1.5 border-r  border-gray-300 w-[100px]">Amount</th>
                <th className="p-1.5 border-r  border-gray-300 w-[100px]">MOP</th>
                <th className="p-1.5 border-r  border-gray-300 w-[120px]">Add By</th>
                <th className="p-1.5 border-r  border-gray-300 w-[120px]">Add On</th>
                <th className="p-1.5 border-r  border-gray-300 w-[120px]" >
                  Receipt Status
                </th>
                <th className="p-1.5 text-center w-[100px]">Action</th>
              </tr>
            </thead>
            <tbody className="text-[11px] divide-y divide-gray-200">
  {list.length === 0 ? (
    <tr>
      <td
        colSpan="10"   // 👈 make sure this matches your total column count
        className="text-center py-6 text-gray-500 font-semibold"
      >
        Receipt Not Found
      </td>
    </tr>
  ) : (
    list.map((item, i) => (
      <tr key={i} className={i % 2 === 0 ? "bg-gray-50" : "bg-white"}>
        <td className="p-1.5 text-blue-800">{item.id}</td>

        <td className="p-1.5">
          {new Date(item.doc_date).toLocaleDateString("en-GB")}
        </td>

        <td className="p-1.5">{item.from_branch_name}</td>

        <td className="p-1.5">{item.to_branch_name}</td>

        <td className="p-1.5 font-bold">
          {item.amount || "-"}
        </td>

        <td className="p-1.5">{item.pay_mode}</td>

        <td className="p-1.5 text-gray-500">Admin</td>

        <td className="p-1.5">
          {item.created_at?.split("T")[0]}
        </td>

        <td
          onClick={() => {
            if (item.status === "Pending") {
              setSelectedItem(item);
              setIsModalOpen(true);
            }
          }}
          className={`p-1.5 font-bold cursor-pointer ${
            item.status === "Pending"
              ? "text-yellow-600 underline"
              : item.status === "Accepted"
              ? "text-green-700"
              : "text-red-600"
          }`}
        >
          {item.status}
        </td>

        <td className="p-1.5 text-center whitespace-nowrap">
          <div className="flex justify-center gap-2">
          <span
            className="bg-blue-500 hover:bg-blue-600 text-white p-1.5 rounded cursor-pointer transition"
            onClick={() =>
              navigate("/FundTransfer/create", {
                state: { fundData: item },
              })
            }
          >

            <Eye size={14} />
          </span>

          <span
            className="bg-red-600 hover:bg-red-700 text-white p-1.5 rounded cursor-pointer transition"
            onClick={() => handleDelete(item.id)}
          >
            <Trash2 size={14} />
            </span>
          </div>
        </td>
      </tr>
    ))
  )}
</tbody>
          </table>
        </div>
        </div>
        
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            {/* 🔹 Background Overlay */}
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm"></div>

            {/* 🔹 Modal Box */}
            <div className="relative bg-white p-6 rounded-lg w-[400px] shadow-xl">
              <h2 className="text-lg font-bold mb-4 text-center">
                Approve Fund Transfer
              </h2>

              <p className="text-center mb-6">
                Do you want to approve this request?
              </p>

              <div className="flex justify-between">
                <button
                  onClick={handleApprove}
                  className="bg-[#0D3082] text-white px-4 py-2 rounded"
                >
                  Approve
                </button>

                <button
                  onClick={handleReject}
                  className="bg-red-600 text-white px-4 py-2 rounded"
                >
                  Reject
                </button>

                <button
                  onClick={() => setIsModalOpen(false)}
                  className="bg-gray-400 text-white px-4 py-2 rounded"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
        {/* Footer */}
        {/* <div className={`${navyBlue} text-white text-[10px] text-center py-1.5 mt-2 rounded-sm uppercase`}>
          © Copyright Maraekat Infotech Ltd, 2015. All rights reserved.
        </div> */}
      </div>
    </div>
  );
};

export default FundTransferReceipt;
