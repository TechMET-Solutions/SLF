import axios from "axios";
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { API } from "../api";
import blockimg from "../assets/blockimg.png";
import envImg from "../assets/envImg.jpg";
import GroupData from "../assets/Group 124.svg";
import msg from "../assets/msg.png";
import print from "../assets/print.png";
import { formatIndianDate } from "../utils/Helpers";
const CustProfile = () => {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalOpenForRemark, setIsModalOpenForRemark] = useState(false);
  const [checkedRows, setCheckedRows] = useState({});
  const editor = useRef(null);
  const [content, setContent] = useState("");
  const [data, setData] = useState([]);
  const [isModalOpenForBlock, setIsModalOpenForblock] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);

  // State for search
  const [searchValue, setSearchValue] = useState("");
  const [searchField, setSearchField] = useState("partyUID"); // default search by Party UID

  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const [searchHeaders, setSearchHeaders] = useState([]); // Array of active headers
  const [searchQuery, setSearchQuery] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleHeader = (headerId) => {
    setSearchHeaders((prev) =>
      prev.includes(headerId)
        ? prev.filter((id) => id !== headerId)
        : [...prev, headerId],
    );
  };

  // Fetch function with search
  // const fetchCustomers = async (
  //   pageNumber = 1,
  //   search = searchValue,
  //   field = searchField,
  // ) => {
  //   try {
  //     const params = {
  //       page: pageNumber,
  //       limit: 10,
  //       searchField: field,
  //     };

  //     // Add search if provided
  //     if (search) params.searchValue = search;

  //     const response = await axios.get(`${API}/Master/doc/searchCustomers`, {
  //       params,
  //     });
  //     setData(response.data.data);
  //     setTotalPages(response.data.totalPages);
  //     setPage(response.data.currentPage);
  //   } catch (error) {
  //     console.error("❌ Error fetching customers:", error);
  //   }
  // };
  const fetchCustomers = async (pageNumber = 1) => {
    try {
      const params = {
        page: pageNumber,
        limit: 10,
        headers: searchHeaders.join(","), // 👈 multiple headers
        search: searchQuery, // 👈 search value
      };

      const response = await axios.get(`${API}/Master/doc/searchCustomers`, {
        params,
      });

      setData(response.data.data);
      setTotalPages(response.data.totalPages);
      setPage(response.data.currentPage);
    } catch (error) {
      console.error("❌ Error fetching customers:", error);
    }
  };

  const [pendingRow, setPendingRow] = useState(null);

  // Handle search
  const handleSearch = () => {
    setPage(1); // Reset to first page when searching
    fetchCustomers(1, searchValue, searchField);
  };

  // Handle search field change
  const handleSearchFieldChange = (e) => {
    const field = e.target.value;
    setSearchField(field);
    setSearchValue(""); // Clear search value when field changes
  };

  // Handle search input change
  const handleSearchInputChange = (e) => {
    setSearchValue(e.target.value);
  };

  // Handle enter key in search input
  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  // Clear search
  const handleClearSearch = () => {
    setSearchField("partyUID");
    setSearchValue("");
    setPage(1);
    fetchCustomers(1, "", "partyUID");
  };

  useEffect(() => {
    fetchCustomers(page);
  }, [page]);

  useEffect(() => {
    document.title = "SLF | Customer List";
    fetchCustomers();
  }, []);

  const handleCheckboxChange = async (row, checked) => {
    if (checked) {
      // Block flow → pehle modal
      setPendingRow(row);
      setIsModalOpenForblock(true);
    } else {
      // Unblock directly
      try {
        await axios.post(`${API}/Master/doc/blockUnblockCustomer`, {
          id: row.id,
          block: false,
        });

        setCheckedRows((prev) => ({
          ...prev,
          [row.id]: false,
        }));

        alert("Customer unblocked successfully");
        fetchCustomers(page, searchValue, searchField);
      } catch (err) {
        console.error("Error unblocking customer:", err);
        alert("Failed to unblock customer");
      }
    }
  };

  const handleBlockConfirm = async () => {
    try {
      await axios.post(`${API}/Master/doc/blockUnblockCustomer`, {
        id: pendingRow.id,
        block: true,
      });

      setCheckedRows((prev) => ({
        ...prev,
        [pendingRow.id]: true,
      }));

      alert("Customer blocked successfully");
      setIsModalOpenForblock(false);
      setPendingRow(null);
      fetchCustomers(page, searchValue, searchField);
    } catch (err) {
      console.error("Error blocking customer:", err);
      alert("Failed to block customer");
    }
  };

  const handleOpenRemark = (customer) => {
    setSelectedCustomer(customer);
    setContent(customer.Remark || "");
    setIsModalOpenForRemark(true);
  };

  const handleNavigateToProfile = (row) => {
    navigate("/Add-Customer-Profile", {
      state: {
        customerData: row,
        type: "edit",
      },
    });
  };

  // Get placeholder text based on selected search field
  const getPlaceholderText = () => {
    switch (searchField) {
      case "partyUID":
        return "Search by Party UID...";
      case "fname":
        return "Search by First Name...";
      case "mname":
        return "Search by Middle Name...";
      case "lname":
        return "Search by Last Name...";
      case "city":
        return "Search by City...";
      case "mobile":
        return "Search by Mobile Number...";
      default:
        return "Search...";
    }
  };

  return (
    <div className="min-h-screen w-full">
      {/* middletopbar */}
      <div className="flex justify-center sticky top-[80px] z-40">
        <div className="flex items-center px-6 py-4 border-b mt-5 w-[1290px] h-[62px] border rounded-[11px] border-gray-200 justify-between shadow bg-white">
          {/* Left heading */}
          <h2
            style={{
              fontFamily: "Source Sans 3, sans-serif",
              fontWeight: 700,
              fontSize: "20px",
              lineHeight: "148%",
              letterSpacing: "0em",
            }}
            className="text-red-600"
          >
            Customer Profile List
          </h2>

          {/* Right section (search + buttons) */}
          <div className="flex items-center gap-6">
            {/* Search section */}
            {/* <div className="flex gap-5">
              <div className="flex gap-3 items-center">
                <p className="text-[11.25px] font-source">Search By</p>
                <select
                  value={searchField}
                  onChange={handleSearchFieldChange}
                  style={{
                    width: "140px",
                    height: "27.49px",
                    borderRadius: "5px",
                    borderWidth: "0.62px",
                  }}
                  className="border border-gray-400 px-3 py-1 text-[11.25px] font-source"
                >
                  <option value="partyUID">Party UID</option>
                  <option value="fname">F Name</option>
                  <option value="mname">M Name</option>
                  <option value="lname">L Name</option>
                  <option value="city">City</option>
                  <option value="mobile">Mobile Number</option>
                </select>
              </div>

              <div className="flex gap-3 items-center">
                <input
                  type="text"
                  placeholder={getPlaceholderText()}
                  value={searchValue}
                  onChange={handleSearchInputChange}
                  onKeyPress={handleKeyPress}
                  style={{
                    width: "168.64px",
                    height: "27.49px",
                    borderRadius: "5px",
                    borderWidth: "0.62px",
                  }}
                  className="border border-gray-400 px-3 py-1 text-[11.25px] font-source"
                />

                <button
                  onClick={handleSearch}
                  style={{
                    width: "84.36px",
                    height: "26.87px",
                    borderRadius: "5px",
                  }}
                  className="bg-[#0b2c69] text-white text-[11.25px] font-source font-normal flex items-center justify-center"
                >
                  Search
                </button>

                <button
                  onClick={handleClearSearch}
                  style={{
                    width: "84.36px",
                    height: "26.87px",
                    borderRadius: "5px",
                  }}
                  className="bg-[#6c757d] text-white text-[11.25px] font-source font-normal flex items-center justify-center"
                >
                  Clear
                </button>
              </div>
            </div> */}

            <div className="flex items-center gap-3">
              <div className="flex items-center bg-white border border-gray-400 rounded-[5px] h-[32px] px-2 relative w-[500px]">
                {/* Multi-Select Header Dropdown */}
                <div className="relative border-r border-gray-300 pr-2 mr-2">
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="text-[11px] font-source font-bold text-[#0A2478] flex items-center gap-1 outline-none h-full"
                  >
                    Headers ({searchHeaders.length}){" "}
                    <span className="text-[8px]">▼</span>
                  </button>

                  {isDropdownOpen && (
                    <div className="absolute top-[35px] left-[-8px] bg-white border border-gray-300 shadow-xl rounded-md z-[100] w-[160px] p-2">
                      {[
                        { id: "id", label: "Party UID" },
                        { id: "firstName", label: "F Name" },
                        { id: "middleName", label: "M Name" },
                        { id: "lastName", label: "L Name" },
                        { id: "Corresponding_City", label: "City" },
                        { id: "mobile", label: "Mobile Number" },
                        { id: "panNo", label: "Pan Card" },
                        { id: "aadhar", label: "Aadhar Card" },
                      ].map((col) => (
                        <label
                          key={col.id}
                          className="flex items-center gap-2 p-2 hover:bg-gray-50 cursor-pointer rounded"
                        >
                          <input
                            type="checkbox"
                            checked={searchHeaders.includes(col.id)}
                            onChange={() => toggleHeader(col.id)}
                            className="w-3 h-3 accent-[#0A2478]"
                          />
                          <span className="text-[11px] font-source text-gray-700">
                            {col.label}
                          </span>
                        </label>
                      ))}
                      <div className="border-t mt-1 pt-1 text-center">
                        <button
                          onClick={() => setIsDropdownOpen(false)}
                          className="text-[10px] text-[#0A2478] font-bold"
                        >
                          Apply
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Text Input Field */}
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Type multiple items (e.g. Cash, Asset)..."
                  className="flex-grow text-[11px] font-source outline-none h-full"
                />

                {/* Search Button */}
                {/* <button
                  onClick={() => {
                    setIsDropdownOpen(false);
                    // getAccountGroups();
                  }}
                  className="ml-2 bg-[#0b2c69] text-white text-[11px] px-4 h-[24px] rounded-[3px] font-source hover:bg-[#071d45]"
                >
                  Search
                </button> */}

                <button
                  className="ml-2 bg-[#0b2c69] text-white text-[11px] px-4 h-[24px] rounded-[3px] font-source hover:bg-[#071d45]"
                  onClick={() => {
                    setIsDropdownOpen(false);
                    fetchCustomers(1);
                  }}
                >
                  Search
                </button>
                <button
                  onClick={() => {
                    setSearchQuery("");
                    setSearchHeaders([]);
                    fetchCustomers();
                  }}
                  className="ml-2 bg-[#0b2c69] text-white text-[11px] px-4 h-[24px] rounded-[3px] font-source hover:bg-[#071d45]"
                >
                  Clear
                </button>
              </div>
            </div>
            
            {/* Buttons stuck to right */}
            <div className="flex gap-3">
              <button
                style={{
                  width: "74px",
                  height: "24px",
                  borderRadius: "3.75px",
                }}
                onClick={() => navigate("/Add-Customer-Profile")}
                className="bg-[#0A2478] text-white text-[11.25px] font-source font-normal flex items-center justify-center"
              >
                Add
              </button>

              <button
                onClick={() => navigate("/")}
                className="text-white px-[6.25px] py-[6.25px] rounded-[3.75px] bg-[#C1121F] w-[74px] h-[24px] opacity-100 text-[10px]"
              >
                Exit
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* modelforAdd */}
      {isModalOpen && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50"
          style={{
            background: "#0101017A",
            backdropFilter: "blur(6.8px)",
          }}
        >
          <div className="bg-white w-[717px] rounded-lg shadow-lg h-[322px] p-10">
            <h2
              className="text-[#0A2478] mb-4"
              style={{
                fontFamily: "Source Sans 3, sans-serif",
                fontWeight: 600,
                fontSize: "20px",
                lineHeight: "24px",
                letterSpacing: "0%",
              }}
            >
              Add New Account Group
            </h2>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[14px]">
                  Group Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Interest Accrued on FDR"
                  className="border border-gray-300 rounded"
                  style={{
                    width: "280px",
                    height: "38px",
                    padding: "10px 14px",
                    borderRadius: "5px",
                    borderWidth: "1px",
                    opacity: 1,
                  }}
                />
              </div>
              <div>
                <label className="text-[14px]">
                  Account Type <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Current Assets"
                  className="border border-gray-300 rounded"
                  style={{
                    width: "280px",
                    height: "38px",
                    padding: "10px 14px",
                    borderRadius: "5px",
                    borderWidth: "1px",
                    opacity: 1,
                  }}
                />
              </div>
              <div>
                <label className="text-[12px] font-medium">Under</label>
                <select
                  className="border border-gray-300 rounded px-2 py-1 w-full mt-1 text-[12px]"
                  style={{
                    width: "280px",
                    height: "38px",
                    padding: "10px 14px",
                    borderRadius: "5px",
                    borderWidth: "1px",
                    opacity: 1,
                  }}
                >
                  <option>Balance Sheet</option>
                  <option>Income Statement</option>
                </select>
              </div>
              <div>
                <label className="text-[12px] font-medium">Comments</label>
                <input
                  type="text"
                  className="border border-gray-300 rounded px-2 py-1 w-full mt-1 text-[12px]"
                  placeholder="Test"
                  style={{
                    width: "280px",
                    height: "38px",
                    padding: "10px 14px",
                    borderRadius: "5px",
                    borderWidth: "1px",
                    opacity: 1,
                  }}
                />
              </div>
            </div>
            <div className="flex justify-center gap-5 items-center">
              <div className="flex justify-end gap-3 mt-6 item-center">
                <button
                  className="bg-[#0A2478] text-white"
                  style={{
                    width: "92.66px",
                    height: "30.57px",
                    borderRadius: "4.67px",
                    opacity: 1,
                  }}
                  onClick={() => setIsModalOpen(false)}
                >
                  Save
                </button>

                <button
                  className="text-white"
                  style={{
                    backgroundColor: "#C1121F",
                    width: "92.66px",
                    height: "30.57px",
                    borderRadius: "4.67px",
                    opacity: 1,
                  }}
                  onClick={() => setIsModalOpen(false)}
                >
                  Exit
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* {isModalOpenForRemark && (
        <div className="fixed inset-0 flex items-center justify-center z-50"
          style={{
            background: "#0101017A",
            backdropFilter: "blur(6.8px)",
          }}>
          <div className="bg-white w-[829px] rounded-lg shadow-lg h-[356px] p-10">
            <h2
              className="text-[#0A2478] mb-4"
              style={{
                fontFamily: "Source Sans 3, sans-serif",
                fontWeight: 600,
                fontSize: "20px",
                lineHeight: "24px",
                letterSpacing: "0%",
              }}
            >
              Remark
            </h2>

            <JoditEditor
              ref={editor}
              value={content}
              onChange={(newContent) => setContent(newContent)}
            />

            <div className="flex justify-center gap-5 items-center">
              <div className="flex justify-end gap-3 mt-6 item-center">
                <button
                  className="text-white"
                  style={{
                    backgroundColor: "#C1121F",
                    width: "92.66px",
                    height: "30.57px",
                    borderRadius: "4.67px",
                    opacity: 1,
                  }}
                  onClick={() => setIsModalOpenForRemark(false)}
                >
                  Exit
                </button>
              </div>
            </div>
          </div>
        </div>
      )} */}
      {isModalOpenForRemark && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
          style={{
            background: "#0101017A",
            backdropFilter: "blur(6.8px)",
          }}
        >
          <div className="bg-white w-[829px] h-[356px] p-6 shadow-lg relative rounded-[8px]">
            <h2
              className="font-semibold text-[24px] leading-[100%] tracking-[0.03em] mb-4 text-[#0A2478]"
              style={{ fontFamily: "Source Sans 3" }}
            >
              Remark
            </h2>

            <div className="w-[728px] border border-gray-300 p-5 resize-none h-[183px] rounded-[16px] flex justify-between">
              <div>
                {/* <p className="text-black font-bold text-[14px]">
                    Remark for Loan #{remarkData?.id}
                  </p> */}
                <p
                  className="text-[14px] mt-2 text-[#000000C7]"
                  dangerouslySetInnerHTML={{
                    __html: content || "No remark available",
                  }}
                ></p>
              </div>
              <div>
                <img
                  src={envImg}
                  alt="envelope"
                  className="w-[156px] h-[156px] rounded-[10px]"
                />
              </div>
            </div>

            <div className="flex justify-center mt-4 gap-2">
              <button
                className="px-4 py-2 rounded w-[119px] h-[38px] bg-[#C1121F] text-white font-semibold cursor-pointer hover:bg-[#a50e1a]"
                onClick={() => {
                  setIsModalOpenForRemark(false);
                  setContent("");
                }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {isModalOpenForBlock && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50"
          style={{
            background: "#0101017A",
            backdropFilter: "blur(6.8px)",
          }}
        >
          <div className="bg-white w-[396px] rounded-lg shadow-lg h-[386px] p-5">
            <div className="flex justify-center items-center mt-2">
              <img
                src={blockimg}
                alt="action"
                className="w-[113px] h-[113px]"
              />
            </div>
            <div className="mt-10">
              <p className="font-[Source_Sans_3] font-normal text-[21.79px] text-center">
                Are you sure to Block this Customer
              </p>
              <p className="font-[Source_Sans_3] font-normal text-[17.43px] text-center text-[#7C7C7C] mt-2">
                You won't be able to revert this action
              </p>
            </div>

            <div className="mt-5 grid justify-center">
              <div className="pl-3">
                <button
                  className="bg-[#F11717] text-white font-semibold text-[19.61px] w-[67.53px] h-[30.57px] rounded-[2.67px]"
                  onClick={handleBlockConfirm}
                >
                  Ok
                </button>
              </div>

              <div className="mt-4">
                <button
                  className="text-white text-[19px]"
                  style={{
                    backgroundColor: "#0A2478",
                    width: "100.66px",
                    height: "30.57px",
                    borderRadius: "2.67px",
                  }}
                  onClick={() => {
                    setIsModalOpenForblock(false);
                    setPendingRow(null);
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="flex justify-center">
        <div className="overflow-x-auto mt-5 w-[1290px] h-[500px]">
          <table className="w-full border-collapse">
            <thead className="bg-[#0A2478] text-white text-sm">
              <tr>
                <th className="px-4 py-2 text-left border-r border-gray-300 text-[13px]">
                  Customer
                </th>
                <th className="px-4 py-2 text-left border-r border-gray-300 text-[13px]">
                  Party UID
                </th>
                <th className="px-4 py-2 text-left border-r border-gray-300 text-[13px]">
                  F Name
                </th>
                <th className="px-4 py-2 text-left border-r border-gray-300 text-[13px]">
                  M Name
                </th>
                <th className="px-4 py-2 text-left border-r border-gray-300 text-[13px]">
                  L Name
                </th>
                <th className="px-4 py-2 text-left border-r border-gray-300 text-[13px]">
                  City
                </th>
                <th className="px-4 py-2 text-left border-r border-gray-300 text-[13px]">
                  Mobile Number
                </th>
                {/* <th className="px-4 py-2 text-left border-r border-gray-300 text-[13px]">Bad Debtor</th> */}
                <th className="px-4 py-2 text-left border-r text-[13px]">
                  Added On
                </th>
                <th className="px-4 py-2 text-left border-r text-[13px]">
                  Added By
                </th>
                <th className="px-4 py-2 text-left border-r text-[13px]">
                  Block
                </th>
                <th className="px-4 py-2 text-center text-[13px]">Action</th>
              </tr>
            </thead>

            <tbody className="text-[12px]">
              {data.map((row, index) => (
                <tr
                  key={index}
                  className={`border-b 
              ${
                row.badDebtor
                  ? "bg-red-100 text-red-700 font-semibold"
                  : index % 2 === 0
                    ? "bg-gray-50"
                    : "bg-white"
              }
            `}
                >
                  <td className="px-4 py-2 flex items-center gap-3">
                    <img
                      src={row.profileImage}
                      alt={row.customer}
                      className="w-10 h-10 rounded-full object-cover border border-gray-300"
                    />
                    <span className="font-medium">{row.customer}</span>
                  </td>

                  <td className="px-4 py-2">{row.id}</td>
                  <td className="px-4 py-2">{row.firstName}</td>
                  <td className="px-4 py-2">{row.middleName}</td>
                  <td className="px-4 py-2">{row.lastName}</td>
                  <td className="px-4 py-2">{row.Permanent_City}</td>
                  <td className="px-4 py-2">{row.mobile}</td>

                  {/* <td className="px-4 py-2 font-bold text-center">
              {row.badDebtor ? "Yes" : "No"}
            </td> */}

                  <td className="px-4 py-2">
                    {formatIndianDate(row.Added_On)}
                  </td>
                  <td className="px-4 py-2">{row.Added_By}</td>

                  <td className="px-4 py-2">
                    <input
                      type="checkbox"
                      className="w-[25px] h-[25px]"
                      checked={checkedRows[row.id] ?? row.block === 1}
                      onChange={(e) =>
                        handleCheckboxChange(row, e.target.checked)
                      }
                    />
                  </td>

                  <td className="px-4 py-2 text-[#1883EF] cursor-pointer">
                    <div className="flex gap-5">
                      <div
                        className="w-[17px] h-[17px] bg-[#6D5300] rounded-[2.31px] flex items-center justify-center cursor-pointer"
                        onClick={() => handleOpenRemark(row)}
                      >
                        <img
                          src={msg}
                          alt="remark"
                          className="w-[12px] h-[12px]"
                          title="Remark"
                        />
                      </div>

                      <div
                        className="w-[17px] h-[17px] bg-[#56A869] rounded-[2.31px] flex items-center justify-center cursor-pointer"
                        onClick={() => handleNavigateToProfile(row)}
                      >
                        <img
                          src={GroupData}
                          alt="edit"
                          className="w-[12px] h-[12px]"
                          title="Edit"
                        />
                      </div>

                      <div
                        className="w-[17px] h-[17px] bg-[#83090B] rounded-[2.31px] flex items-center justify-center cursor-pointer"
                        onClick={() =>
                          navigate("/Customer_Form", { state: row })
                        }
                      >
                        <img
                          src={print}
                          alt="print"
                          className="w-[12px] h-[12px]"
                          title="Print"
                        />
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex justify-center items-center px-6 py-3 border-t gap-2">
        <button
          onClick={() => {
            const newPage = Math.max(page - 1, 1);
            setPage(newPage);
            fetchCustomers(newPage, searchValue, searchField);
          }}
          disabled={page === 1}
          className="px-3 py-1 border rounded-md disabled:opacity-50"
        >
          Previous
        </button>

        <div className="flex gap-2">
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i + 1}
              onClick={() => {
                setPage(i + 1);
                fetchCustomers(i + 1, searchValue, searchField);
              }}
              className={`px-3 py-1 border rounded-md ${
                page === i + 1 ? "bg-[#0b2c69] text-white" : ""
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>

        <button
          onClick={() => {
            const newPage = Math.min(page + 1, totalPages);
            setPage(newPage);
            fetchCustomers(newPage, searchValue, searchField);
          }}
          disabled={page === totalPages}
          className="px-3 py-1 border rounded-md disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default CustProfile;
