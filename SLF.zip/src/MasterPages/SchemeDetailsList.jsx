import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { API } from "../api";
import Pagination from "../Component/Pagination";
import { formatIndianDate } from "../utils/Helpers";
const SchemeDetailsList = () => {
  useEffect(() => {
    document.title = "SLF | Scheme Details List";
  }, []);

  const navigate = useNavigate();

  const [data, setData] = useState([]);

  console.log(data, "data");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // 🔥 Fetch Schemes With Pagination

  const [searchHeaders, setSearchHeaders] = useState([]); // Array of active headers
  const [searchQuery, setSearchQuery] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [appFrom, setAppFrom] = useState("");
  const [appTo, setAppTo] = useState("");

  // Update your handleClearSearch to include these
  const handleClearSearch = () => {
    setSearchQuery("");
    setAppFrom("");
    setAppTo("");
    // setFilteredData(schemes);
  };
  //  const fetchSchemes = async (page = 1) => {
  //     try {
  //       const response = await axios.get(
  //         `${API}/Scheme/getAllSchemes?page=${page}&limit=10`,
  //       );

  //       // Backend returns: { page, limit, totalItems, totalPages, data }
  //       const result = response.data.data;

  //       setData(result); // only the list
  //       setCurrentPage(result.page);
  //       setTotalPages(result.totalPages);
  //     } catch (err) {
  //       console.error("❌ Error fetching schemes:", err);
  //     }
  //   };
 const fetchSchemes = async (page = 1) => {
  try {
    const response = await axios.get(`${API}/Scheme/getAllSchemes`, {
      params: {
        page,
        limit: 10,
        search: searchQuery || undefined,
        keys: searchHeaders.length ? searchHeaders.join(",") : undefined,
        appFrom: appFrom || undefined,
        appTo: appTo || undefined,
      },
    });

    const result = response.data;   // ✅ Correct

    setData(result.items);          // ✅ Use items
    setCurrentPage(result.page);    // ✅ From API
    setTotalPages(result.totalPages);

  } catch (err) {
    console.error("❌ Error fetching schemes:", err);
  }
};


  useEffect(() => {
    fetchSchemes(currentPage);
  }, []);

  const toggleHeader = (headerId) => {
    setSearchHeaders((prev) =>
      prev.includes(headerId)
        ? prev.filter((id) => id !== headerId)
        : [...prev, headerId],
    );
  };

  // 🔹 Pagination Controls
  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return;
    fetchSchemes(page);
  };

  // 🔹 Toggle Active/Inactive
  const handleStatusToggle = async (row) => {
    const newStatus = row.status === 1 ? 0 : 1;

    try {
      await axios.patch(`${API}/Scheme/statusScheme`, {
        id: row.id,
        status: newStatus,
      });

      // Update UI without refresh
      const updated = data.map((item) =>
        item.id === row.id ? { ...item, status: newStatus } : item,
      );
      setData(updated);
    } catch (err) {
      console.error("Error updating scheme status:", err);
      alert("Failed to update status");
    }
  };

  return (
    <div className="min-h-screen w-full">
      {/* Top Bar */}
      <div className="flex justify-center sticky top-[80px] z-40">
        <div className="flex items-center px-6 py-4 border-b mt-5 w-[1290px] h-[62px] border rounded-[11px] border-gray-200 justify-between shadow bg-white">
          <h2 className="text-red-600 text-[20px] font-semibold">
            Scheme List
          </h2>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-3">
              <div className="flex items-center bg-white border border-gray-400 rounded-[5px] h-[32px] px-2 relative w-[300px]">
                {/* Multi-Select Header Dropdown */}
                <div className="relative border-r border-gray-300 pr-2 mr-2">
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="text-[11px] font-source font-bold text-[#0A2478] flex items-center gap-1 outline-none h-full"
                  >
                    Headers ({searchHeaders.length}){" "}
                    <span className="text-[8px]">▼</span>
                  </button>

                  {isDropdownOpen && (
                    <div className="absolute top-[35px] left-[-8px] bg-white border border-gray-300 shadow-xl rounded-md z-[100] w-[160px] p-2">
                      {[
                        { id: "schemeName", label: "Scheme Name" },
                        { id: "product", label: "Product Name" },
                        { id: "minLoanAmount", label: "Min Loan Amount" },
                        { id: "maxLoanAmount", label: "Max Loan Amount" },
                      ].map((col) => (
                        <label
                          key={col.id}
                          className="flex items-center gap-2 p-2 hover:bg-gray-50 cursor-pointer rounded"
                        >
                          <input
                            type="checkbox"
                            checked={searchHeaders.includes(col.id)}
                            onChange={() => toggleHeader(col.id)}
                            className="w-3 h-3 accent-[#0A2478]"
                          />
                          <span className="text-[11px] font-source text-gray-700">
                            {col.label}
                          </span>
                        </label>
                      ))}
                      <div className="border-t mt-1 pt-1 text-center">
                        <button
                          onClick={() => setIsDropdownOpen(false)}
                          className="text-[10px] text-[#0A2478] font-bold"
                        >
                          Apply
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Text Input Field */}
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Type multiple items (e.g. Cash, Asset)..."
                  className="flex-grow text-[11px] font-source outline-none h-full"
                />

                {/* Search Button */}
                <button
                  onClick={() => fetchSchemes(1)}
                  className="ml-2 bg-[#0b2c69] text-white text-[11px] px-4 h-[24px] rounded-[3px]"
                >
                  Search
                </button>
              </div>

              <div className="flex items-center bg-white border border-gray-400 rounded-[5px] h-[32px] px-2 relative">
                {/* App From Date */}
                <div className="flex items-center gap-1 border-r border-gray-200 pr-2 mr-2">
                  <span className="text-[10px] text-gray-500 font-bold uppercase">
                    From
                  </span>
                  <input
                    type="date"
                    value={appFrom}
                    onChange={(e) => setAppFrom(e.target.value)}
                    className="w-[110px] text-[11px] outline-none cursor-pointer bg-transparent uppercase"
                  />
                </div>

                {/* App To Date */}
                <div className="flex items-center gap-1 border-r border-gray-200 pr-2 mr-2">
                  <span className="text-[10px] text-gray-500 font-bold uppercase">
                    To
                  </span>
                  <input
                    type="date"
                    value={appTo}
                    onChange={(e) => setAppTo(e.target.value)}
                    className="w-[110px] text-[11px] outline-none cursor-pointer bg-transparent uppercase"
                  />
                </div>

                {/* Search Button */}
                <button
                  onClick={() => fetchSchemes(1)}
                  className="ml-2 bg-[#0b2c69] text-white text-[11px] px-4 h-[24px] rounded-[3px]"
                >
                  Search
                </button>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setSearchHeaders([]);
                  setSearchQuery("");
                  setAppFrom("");
                  setAppTo("");
                  fetchSchemes(1);
                }}
                className="bg-gray-500 text-white text-[11px] px-4 py-1 rounded"
              >
                Clear
              </button>

              <button
                className="bg-[#129121] text-white text-[11.25px] px-4 py-1 rounded"
                onClick={() => navigate("/Scheme-Renewal-List")}
              >
                Renew
              </button>

              <button
                className="bg-[#0A2478] text-white text-[11.25px] px-4 py-1 rounded"
                onClick={() => navigate("/Add-Scheme-Details-Listform")}
              >
                Add
              </button>

              <button
                onClick={() => navigate("/")}
                className="bg-[#C1121F] text-white w-[74px] h-[24px] rounded text-[10px]"
              >
                Exit
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="flex justify-center">
        <div className="overflow-x-auto mt-5  h-[500px]">
          <table className="w-full border-collapse">
            <thead className="bg-[#0A2478] text-white text-sm">
              <tr>
                <th className="px-4 py-2 border w-[200px]">Scheme Name</th>
                <th className="px-4 py-2 border w-[100px]">Product Name</th>
                <th className="px-4 py-2 border">App From</th>
                <th className="px-4 py-2 border">App To</th>
                <th className="px-4 py-2 border w-[50px]">Int. Compound</th>

                <th className="px-4 py-2 border">Min Amount</th>
                <th className="px-4 py-2 border">Max Amount</th>

                <th className="px-4 py-2 border w-[300px]">Description</th>
                {/* <th className="px-4 py-2 border">Action</th> */}
                <th className="px-4 py-2 border w-[110px]">Role Mapping</th>
                <th className="px-4 py-2 border ">Active</th>
              </tr>
            </thead>

            <tbody className="text-[12px] text-center">
              {data?.map((row, index) => (
                <tr
                  key={row.id}
                  className={index % 2 === 0 ? "bg-gray-50" : "bg-white"}
                >
                  <td
                    className="px-4 py-2 cursor-pointer hover:underline text-blue-500"
                    onClick={() =>
                      navigate("/Add-Scheme-Details-Listform", {
                        state: { type: "view", data: row },
                      })
                    }
                  >
                    {row.schemeName}
                  </td>
                  <td className="px-4 py-2">{row.product}</td>

                  <td className="px-4 py-2">
                    {formatIndianDate(row.applicableFrom)}
                  </td>
                  <td className="px-4 py-2">
                    {formatIndianDate(row.applicableTo)}
                  </td>
                  <td className="px-4 py-2">
                    {row.calcMethod === "Compound" ? "True" : "False"}
                  </td>
                  <td className="px-4 py-2">{row.minLoanAmount}</td>
                  <td className="px-4 py-2">{row.maxLoanAmount}</td>

                  <td className="px-4 py-2">{row.description}</td>

                  {/* <td className="px-4 py-2 text-center">
                    <div className="flex items-center gap-2">
                      
                      <div
                        className="w-5 h-5 bg-[#646AD9] flex items-center justify-center rounded cursor-pointer"
                        onClick={() =>
                          navigate("/Add-Scheme-Details-Listform", {
                            state: { type: "view", data: row },
                          })
                        }
                      >
                        <img src={eyeIcon} className="w-3.5 h-2.5" />
                      </div>
                    </div>
                  </td> */}

                  {/* Role Mapping */}
                  <td
                    className="px-4 py-2 text-[#1883EF] cursor-pointer"
                    onClick={() =>
                      navigate("/Role-Mapping", { state: { data: row } })
                    }
                  >
                    Role Mapping
                  </td>

                  {/* Toggle */}
                  <td className="px-4 py-2">
                    <button
                      onClick={() => handleStatusToggle(row)}
                      className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                        row.status === 1 ? "bg-[#0A2478]" : "bg-gray-400"
                      }`}
                    >
                      <div
                        className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                          row.status === 1 ? "translate-x-6" : "translate-x-0"
                        }`}
                      />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      )}
    </div>
  );
};

export default SchemeDetailsList;
