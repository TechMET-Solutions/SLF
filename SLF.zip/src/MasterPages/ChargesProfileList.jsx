import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../API/Context/AuthContext";
import { API } from "../api";
import GroupData from "../assets/Group 124.svg";
import DeleteData from "../assets/deletimg.png";
import { decryptData, encryptData } from "../utils/cryptoHelper";
import { FiEdit, FiTrash2 } from "react-icons/fi";
import Pagination from "../Component/Pagination";

const ChargesProfileList = () => {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [data, setData] = useState([]);
  const [editingId, setEditingId] = useState(null); // To track which profile is being edited
  const [isview, setIsview] = useState(null);
  const [accountList, setAccountList] = useState([]);
  const [formData, setFormData] = useState({
    code: "",
    description: "",
    amount: "",
    account: "",
    isActive: true,
    addedBy: "",
  });
  const { loginUser } = useAuth();

  const [searchFilters, setSearchFilters] = useState({
    code: "",
    Description: "",
  });

  // 2. Handle Input Changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSearchFilters((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // 3. Define the missing handleKeyPress function
  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  // 4. Search Logic
  const handleSearch = () => {
    console.log("Searching for:", searchFilters);
    // Add your API call or filtering logic here using searchFilters.type and searchFilters.name
  };

  // const handleClearSearch = () => {
  //   setSearchFilters({ code: "", Description: "" });
  // };

  console.log("Logged in user:", loginUser);

 

  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        const res = await axios.get(`${API}/account-code/get`);
        setAccountList(res.data.data); // res.data = [ { id, name, ... } ]
      } catch (err) {
        console.log("Error fetching account list", err);
      }
    };

    fetchAccounts();
  }, []);
  

  const [currentPage, setCurrentPage] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [showPagination, setShowPagination] = useState(false);

  const itemsPerPage = 10;

  const fetchChargeProfiles = async (page = 1) => {
    try {
      const response = await axios.get(
        `${API}/Master/GetChargesProfile/get`,
        {
          params: {
            code: searchFilters.code,
            description: searchFilters.Description,
            page: page,
            limit: itemsPerPage,
          },
        }
      );

      if (response.status === 200) {
        setData(response.data.data || []);

        // 🔥 Pagination from backend
        const pagination = response.data.pagination;

        if (pagination) {
          setTotalItems(pagination.total);
          setTotalPages(pagination.totalPages);
          setShowPagination(pagination.showPagination);
          setCurrentPage(pagination.page);
        }
      }
    } catch (error) {
      console.error("❌ Error fetching charge profiles:", error);
      alert("❌ Failed to fetch charge profiles");
    }
  };

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return;
    setCurrentPage(page);
  };

  // Handle input changes
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSave = async () => {
    try {
      let payloadObj;

      if (editingId) {
        // 🟡 UPDATE
        payloadObj = {
          ...formData,
          id: editingId,
        };
      } else {
        // 🟢 ADD
        payloadObj = {
          ...formData,
          addedBy: loginUser, // ⭐ Add logged-in user on save
        };
      }

      const encryptedPayload = encryptData(JSON.stringify(payloadObj));

      let response;
      if (editingId) {
        response = await axios.put(`${API}/Master/updateChargesProfile`, {
          data: encryptedPayload,
        });
      } else {
        response = await axios.post(`${API}/Master/ChargesProfile/add`, {
          data: encryptedPayload,
        });
      }

      if (response.status === 200 || response.status === 201) {
        const decryptedText = decryptData(response.data.data);
        const parsedData =
          typeof decryptedText === "string"
            ? JSON.parse(decryptedText)
            : decryptedText;

        alert(`✅ ${parsedData.message}`);
        setIsModalOpen(false);
        setEditingId(null);

        setFormData({
          code: "",
          description: "",
          amount: "",
          account: "",
          isActive: true,
          addedBy: "",
        });

        fetchChargeProfiles();
      }
    } catch (error) {
      console.error("❌ Error saving/updating charge profile:", error);
      alert("❌ Failed to save/update. Please try again.");
    }
  };

  useEffect(() => {
    fetchChargeProfiles(currentPage);
  }, [currentPage]);

  // ✅ Edit a profile
  const handleEdit = (profile) => {
    setEditingId(profile.id);
    setFormData({
      code: profile.code,
      description: profile.description,
      amount: profile.amount,
      account: profile.account,
      isActive: profile.isActive,
      addedBy: profile.addedBy || "",
    });
    setIsModalOpen(true);
  };
  const handleView = (profile) => {
    setIsview(true);
    setFormData({
      code: profile.code,
      description: profile.description,
      amount: profile.amount,
      account: profile.account,
      isActive: profile.isActive,
      addedBy: profile.addedBy || "",
    });
    setIsModalOpen(true);
  };
  const handleDelete = async (profile) => {
    debugger;
    if (
      !window.confirm("Are you sure you want to delete this charge profile?")
    ) {
      return;
    }

    try {
      // Prepare encrypted payload
      const payload = {
        id: profile.id,
      };
      const encryptedPayload = encryptData(JSON.stringify(payload));

      // Call DELETE API
      const response = await axios.delete(
        `${API}/Master/charge-profile/delete`,
        {
          data: { data: encryptedPayload },
          headers: {
            "Content-Type": "application/json",
          },
        },
      );

      // Decrypt response
      const decryptedResponse = decryptData(response.data.data);
      const result =
        typeof decryptedResponse === "string"
          ? JSON.parse(decryptedResponse)
          : decryptedResponse;

      if (result.message) {
        // Remove deleted profile from local state
        // setChargeProfiles((prev) => prev.filter((p) => p.id !== profile.id));
        alert(result.message);
        fetchChargeProfiles();
      }
    } catch (err) {
      console.error("Error deleting charge profile:", err);
      alert("Failed to delete charge profile");
    }
  };

  // ✅ Toggle active state
  const handleToggle = async (id, currentState) => {
    try {
      const payload = encryptData(
        JSON.stringify({ id, isActive: !currentState }),
      );
      const response = await axios.patch(
        `${API}/Master/statusChangeChargesProfile`,
        { data: payload },
      );

      if (response.status === 200 && response.data?.data) {
        const decrypted = decryptData(response.data.data);
        const parsed =
          typeof decrypted === "string" ? JSON.parse(decrypted) : decrypted;
        // alert(`✅ ${parsed.message}`);
        fetchChargeProfiles();
      }
    } catch (error) {
      console.error("❌ Error updating status:", error);
      alert("❌ Failed to update status");
    }
  };
  const handleClearSearch = () => {
    // 1️⃣ Reset search fields
    setSearchFilters({
      code: "",
      Description: "",
    });

    // 2️⃣ Call API again (fetch all data)
    setCurrentPage(1);
    fetchChargeProfiles(1);
  };

  return (
    <div className="min-h-screen w-full">
      {/* Header and Add Button */}
      <div className="flex justify-center sticky top-[80px] z-40">
        <div className="flex items-center px-6 py-4 border-b mt-5 w-[1290px] h-[62px] border rounded-[11px] border-gray-200 justify-between shadow bg-white">
          <h2 className="text-red-600 font-bold text-[20px] leading-[148%] font-source">
            Charges Profile List
          </h2>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              {/* Type Input */}
              <div className="flex items-center gap-2">
                <p className="text-[11.25px] font-semibold whitespace-nowrap">
                  Code
                </p>
                <input
                  type="text"
                  name="code" // This must match the state key
                  value={searchFilters.code}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyPress} // Use onKeyDown for better compatibility
                  className="border border-gray-400 px-3 py-1 text-[11.25px] rounded outline-none"
                  style={{ width: "120px", height: "27.49px" }}
                />
              </div>

              {/* Name Input */}
              <div className="flex items-center gap-2">
                <p className="text-[11.25px] font-semibold whitespace-nowrap">
                  Description
                </p>
                <input
                  type="text"
                  name="Description" // This must match the state key
                  value={searchFilters.Description}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyPress}
                  className="border border-gray-400 px-3 py-1 text-[11.25px] rounded outline-none"
                  style={{ width: "300px", height: "27.49px" }}
                />
              </div>

              {/* Buttons */}
              <button
                onClick={() => {
                  setCurrentPage(1);
                  fetchChargeProfiles(1);
                }}
                className="bg-[#0b2c69] text-white text-[11px] px-4 py-1 rounded"
              >
                Search
              </button>

              <button
                onClick={handleClearSearch}
                className="bg-[#0b2c69] text-white text-[11px] px-4 py-1 rounded"
              >
                Clear
              </button>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setEditingId(null);
                  setFormData({
                    code: "",
                    description: "",
                    amount: "",
                    account: "",
                    isActive: false,
                    addedBy: "",
                  });
                  setIsModalOpen(true);
                }}
                className="bg-[#0A2478] cursor-pointer text-white text-[11.25px] w-[74px] h-[24px] rounded flex items-center justify-center"
              >
                Add
              </button>
              <button
                onClick={() => navigate("/")}
                className="bg-[#C1121F] text-white text-[10px] px-4 py-1 rounded cursor-pointer"
              >
                Exit
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white w-[500px] rounded-lg shadow-lg h-[320px] p-10">
            <h2 className="text-[#0A2478] text-[20px] font-semibold font-source mb-4">
              {isview
                ? "View Charges Profile"
                : editingId
                  ? "Edit Charges Profile"
                  : "Add Charges Profile"}
            </h2>

            <div className="flex  gap-4">
              {/* Form Fields */}
              <div>
                <p className="text-[14px]">
                  Code <span className="text-red-500">*</span>
                </p>
                <input
                  type="text"
                  name="code"
                  value={formData.code}
                  disabled={isview}
                  onChange={handleChange}
                  className="border border-gray-300 rounded w-[120px] h-[38px] px-3"
                />
              </div>

              <div>
                <p className="text-[14px]">
                  Description <span className="text-red-500">*</span>
                </p>
                <input
                  type="text"
                  name="description"
                  value={formData.description}
                  disabled={isview}
                  onChange={handleChange}
                  className="border border-gray-300 rounded w-[300px] h-[38px] px-3"
                />
              </div>
            </div>
            <div className="flex gap-4 mt-5">
              <div>
                <p className="text-[12px] font-medium">
                  Amount <span className="text-red-500">*</span>
                </p>
                <input
                  type="number"
                  name="amount"
                  value={formData.amount}
                  disabled={isview}
                  onChange={handleChange}
                  style={{
                    MozAppearance: "textfield",
                  }}
                  onWheel={(e) => e.target.blur()}
                  className="border border-gray-300 rounded w-[150px] h-[38px] px-3"
                />
              </div>
              <div>
                <p className="text-[12px] font-medium">
                  Account <span className="text-red-500">*</span>
                </p>
                <select
                  name="account"
                  value={formData.account}
                  disabled={isview}
                  onChange={handleChange}
                  className="border border-gray-300 rounded w-[270px]  h-[38px] px-3"
                >
                  <option value="">-- Select --</option>

                  {accountList?.map((acc) => (
                    <option key={acc.id} value={acc.name}>
                      {acc.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex justify-center gap-3 my-6 mt-10">
              {!isview && (
                <button
                  className="bg-[#0A2478] cursor-pointer text-white w-[92px] h-[30px] rounded"
                  onClick={handleSave}
                >
                  Save
                </button>
              )}

              <button
                className="bg-[#C1121F] cursor-pointer text-white w-[92px] h-[30px] rounded"
                onClick={() => {
                  setIsModalOpen(false); // close modal
                  setEditingId(null); // reset edit tracking
                  setIsview(null); // reset view mode
                  setFormData({
                    // reset form fields
                    code: "",
                    description: "",
                    amount: "",
                    account: "",
                    isActive: false,
                    addedBy: "",
                  });
                }}
              >
                Exit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="flex justify-center">
        <div className="overflow-x-auto mt-5 w-[1290px] h-[500px]">
          <table className="w-full border-collapse">
            <thead className="bg-[#0A2478] text-white text-sm">
              <tr>
                <th className="px-4 py-2 text-left border-r w-[100px]">Code</th>
                <th className="px-4 py-2 text-left border-r w-[500px]">
                  Description
                </th>
                <th className="px-4 py-2 text-left border-r w-[100px]">
                  Amount
                </th>
                <th className="px-4 py-2 text-left border-r w-[250px]">
                  Added By
                </th>
                <th className="px-4 py-2 text-left border-r w-[150px]">
                  Added On
                </th>
                <th className="px-4 py-2 text-left border-r w-[100px]">
                  Action
                </th>
                <th className="px-4 py-2 text-left">Active</th>
              </tr>
            </thead>
            <tbody className="text-[12px]">
              {data?.map((row, index) => (
                <tr
                  key={row.id}
                  className={index % 2 === 0 ? "bg-gray-50" : "bg-white"}
                >
                  <td
                    className="px-4 py-2 text-blue-500 cursor-pointer"
                    onClick={() => handleView(row)}
                  >
                    {row.code}
                  </td>
                  <td className="px-4 py-2">{row.description}</td>
                  <td className="px-4 py-2">{row.amount}</td>
                  <td className="px-4 py-2">{row.addedBy}</td>
                  <td className="px-4 py-2">
                    {new Date(row.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-2 text-[#1883EF] cursor-pointer">
                    <div className="flex gap-2">
                      <div
                        className="bg-[#3dbd5a] cursor-pointer p-1.5 text-white rounded-sm"
                        onClick={() => handleEdit(row)}
                      >
                        <FiEdit className="text-white text-[11px]" />
                      </div>
                      <div
                        className="bg-[#f51111ec] cursor-pointer p-1.5 text-white rounded-sm"
                        onClick={() => handleDelete(row)}
                      >
                        <FiTrash2 className="text-white text-[11px]" />
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-2">
                    <button
                      onClick={() => handleToggle(row.id, row.isActive)}
                      className={`w-12 h-6 flex cursor-pointer items-center rounded-full p-1 transition-colors ${row.isActive ? "bg-[#0A2478]" : "bg-gray-300"
                        }`}
                    >
                      <div
                        className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${row.isActive ? "translate-x-6" : "translate-x-0"
                          }`}
                      />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {/* Pagination Component Hooked up to State */}
      {showPagination && (
        <div className="mt-4 mb-8 flex justify-center">
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={handlePageChange}
          />
        </div>
      )}
    </div>
  );
};

export default ChargesProfileList;
